from Crypto.Util.number import bytes_to_long,getPrime
from hashlib import sha256

f=open('flag.txt','rb').read().strip()
m=bytes_to_long(f)
p=getPrime(512)
q=getPrime(512)
n=p*q
e=3
k=bytes_to_long(sha256(str(n).encode()).digest())
assert m+k<n
c0=pow(m,e,n)
c1=pow(m+k,e,n)
print(f'n = {n}\ne = {e}\nc0 = {c0}\nc1 = {c1}')
